import { f_one } from '@/utils/fonts'
import React from 'react'

const page = () => {
  return (
    <div className='dashhome'>
   <h2 className={`head ${f_one.className}`}>Welcome To Dashboard</h2>
    </div>
  )
}

export default page